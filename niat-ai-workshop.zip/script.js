/**
 * NIAT Offline AI Workshop — Script
 * Features:
 * - Exit-Intent Telugu Popup ("Bro, neekosame! Sunday intlo em chesthav?...")
 * - Exact Image Canvas Pass Exporter with Custom Student Name & Unique ID
 * - Sticky Header Navigation & Smooth Scrolling
 * - Scroll Animations
 * - Single Unified Registration & Dynamic Pass Generation
 * - WhatsApp Community Join & Calendar Integrations
 */

document.addEventListener('DOMContentLoaded', () => {
  initNavbarScroll();
  initMobileNavigation();
  initScrollAnimations();
  initFaqAccordion();
  initRegistrationModal();
  initExitIntentPopup();
  initPassCanvasExporter();
  initCalendarGenerator();
  initWhatsAppShare();
  initInteractiveHeroDemo();
});

// 1. Sticky Header Scroll Indicator
function initNavbarScroll() {
  const header = document.querySelector('.sticky-header-group');
  if (!header) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 30) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });
}

// 2. Mobile Navigation Toggle
function initMobileNavigation() {
  const toggleBtn = document.getElementById('mobile-nav-toggle');
  const navMenu = document.getElementById('header-nav-menu');
  const navLinks = document.querySelectorAll('.header-nav-menu a');

  if (toggleBtn && navMenu) {
    toggleBtn.addEventListener('click', () => {
      navMenu.classList.toggle('mobile-open');
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('mobile-open');
      });
    });
  }
}

// 3. Scroll Intersection Observer Animations
function initScrollAnimations() {
  const animatedElements = document.querySelectorAll('[data-animate]');
  if (!animatedElements.length) return;

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -30px 0px'
    });

    animatedElements.forEach(el => observer.observe(el));
  } else {
    animatedElements.forEach(el => el.classList.add('is-visible'));
  }
}

// 4. FAQ Accordion
function initFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');
  
  faqItems.forEach(item => {
    const btn = item.querySelector('.faq-question-btn');
    const panel = item.querySelector('.faq-answer-panel');
    
    if (!btn || !panel) return;

    btn.addEventListener('click', () => {
      const isActive = item.classList.contains('active');
      
      faqItems.forEach(otherItem => {
        if (otherItem !== item && otherItem.classList.contains('active')) {
          otherItem.classList.remove('active');
          const otherPanel = otherItem.querySelector('.faq-answer-panel');
          if (otherPanel) otherPanel.style.maxHeight = null;
        }
      });

      if (isActive) {
        item.classList.remove('active');
        panel.style.maxHeight = null;
      } else {
        item.classList.add('active');
        panel.style.maxHeight = panel.scrollHeight + 'px';
      }
    });
  });
}

// Global student registration state
const registeredStudentState = {
  name: 'AARAV SHARMA',
  mobile: '',
  email: '',
  school: '',
  city: 'Hyderabad',
  passId: 'NIATAI-8942',
  date: '30 August 2026',
  venue: 'Kapil Kavuri Hub (KKH), Nanakramguda, Financial District, Hyderabad'
};

// 5. Exit-Intent Telugu / English Popup Handler
function initExitIntentPopup() {
  const exitModal = document.getElementById('exit-popup-modal');
  const acceptBtn = document.getElementById('btn-exit-accept');
  const dismissBtn = document.getElementById('btn-exit-dismiss');
  let hasTriggered = false;

  if (!exitModal) return;

  const showExitPopup = () => {
    if (hasTriggered || sessionStorage.getItem('niat_exit_shown')) return;
    hasTriggered = true;
    sessionStorage.setItem('niat_exit_shown', 'true');
    exitModal.classList.add('open');
  };

  const closeExitPopup = () => {
    exitModal.classList.remove('open');
  };

  // Mouseleave on desktop (moving cursor towards tab bar / close button)
  document.addEventListener('mouseleave', (e) => {
    if (e.clientY <= 15) {
      showExitPopup();
    }
  });

  if (acceptBtn) {
    acceptBtn.addEventListener('click', (e) => {
      e.preventDefault();
      closeExitPopup();
      // Trigger registration modal
      const regModal = document.getElementById('registration-modal');
      if (regModal) {
        regModal.classList.add('open');
        document.body.style.overflow = 'hidden';
      }
    });
  }

  if (dismissBtn) {
    dismissBtn.addEventListener('click', (e) => {
      e.preventDefault();
      closeExitPopup();
    });
  }

  exitModal.addEventListener('click', (e) => {
    if (e.target === exitModal) {
      closeExitPopup();
    }
  });
}

// 6. Registration Modal & Pass Generator
function initRegistrationModal() {
  const modal = document.getElementById('registration-modal');
  const openButtons = document.querySelectorAll('.open-reg-modal');
  const closeButtons = document.querySelectorAll('.close-modal-btn');
  const form = document.getElementById('reg-form');
  const stepForm = document.getElementById('modal-step-form');
  const stepSuccess = document.getElementById('modal-step-success');

  if (!modal) return;

  const openModal = () => {
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  };

  const closeModal = () => {
    modal.classList.remove('open');
    document.body.style.overflow = '';
  };

  openButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openModal();
    });
  });

  closeButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal();
    });
  });

  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closeModal();
    }
  });

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const nameInput = document.getElementById('input-student-name');
      const mobileInput = document.getElementById('input-mobile');
      const emailInput = document.getElementById('input-email');
      const schoolInput = document.getElementById('input-school');
      const cityInput = document.getElementById('input-city');

      const studentName = (nameInput && nameInput.value.trim()) ? nameInput.value.trim().toUpperCase() : 'CLASS 12 STUDENT';
      const randomNum = Math.floor(1000 + Math.random() * 9000);
      const generatedPassId = `NIATAI-${randomNum}`;

      registeredStudentState.name = studentName;
      registeredStudentState.mobile = mobileInput ? mobileInput.value.trim() : '';
      registeredStudentState.email = emailInput ? emailInput.value.trim() : '';
      registeredStudentState.school = schoolInput ? schoolInput.value.trim() : '';
      registeredStudentState.city = (cityInput && cityInput.value.trim()) ? cityInput.value.trim() : 'Hyderabad';
      registeredStudentState.passId = generatedPassId;

      // Update UI elements with personalized details
      updatePassDisplay(studentName, generatedPassId);

      // Trigger Confetti
      triggerConfetti();

      // Switch to Success State
      if (stepForm && stepSuccess) {
        stepForm.style.display = 'none';
        stepSuccess.style.display = 'block';
      }
    });
  }

  const editBtn = document.getElementById('btn-edit-pass-details');
  if (editBtn && stepForm && stepSuccess) {
    editBtn.addEventListener('click', () => {
      stepSuccess.style.display = 'none';
      stepForm.style.display = 'block';
    });
  }
}

function updatePassDisplay(name, passId) {
  const nameHolders = document.querySelectorAll('.dynamic-student-name');
  nameHolders.forEach(el => {
    el.textContent = `[ ${name} ]`;
  });

  const passIdHolders = document.querySelectorAll('.dynamic-pass-id');
  passIdHolders.forEach(el => {
    el.textContent = passId;
  });
}

// 7. Canvas Image Pass Exporter (Renders exact template with custom student name & ID overlay)
function initPassCanvasExporter() {
  const downloadBtns = document.querySelectorAll('.btn-download-pass-png');

  downloadBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      generateAndDownloadPassPNG(registeredStudentState.name, registeredStudentState.passId);
    });
  });
}

function generateAndDownloadPassPNG(name, passId) {
  const templateImg = new Image();
  templateImg.crossOrigin = 'anonymous';
  templateImg.src = 'assets/entry_pass_template.jpg';

  templateImg.onload = () => {
    const canvas = document.createElement('canvas');
    canvas.width = templateImg.naturalWidth || 1200;
    canvas.height = templateImg.naturalHeight || 800;
    const ctx = canvas.getContext('2d');

    // Draw base template image
    ctx.drawImage(templateImg, 0, 0, canvas.width, canvas.height);

    // Cover original [STUDENT NAME] placeholder area with matching ivory background
    const nameY = canvas.height * 0.38;
    ctx.fillStyle = '#FAF6EE';
    ctx.fillRect(canvas.width * 0.15, canvas.height * 0.28, canvas.width * 0.7, canvas.height * 0.14);

    // Draw customized Student Name in Bold Maroon
    ctx.fillStyle = '#7B1113';
    ctx.font = `900 ${Math.floor(canvas.height * 0.088)}px "Outfit", "Plus Jakarta Sans", sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`[ ${name} ]`, canvas.width / 2, nameY);

    // Cover original [PASS ID] placeholder area on bottom right
    const idX = canvas.width * 0.81;
    const idY = canvas.height * 0.88;
    ctx.fillStyle = '#FFFDF9';
    ctx.fillRect(canvas.width * 0.74, canvas.height * 0.83, canvas.width * 0.17, canvas.height * 0.08);

    // Draw customized Pass ID
    ctx.fillStyle = '#7B1113';
    ctx.font = `900 ${Math.floor(canvas.height * 0.048)}px "JetBrains Mono", monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(passId, idX, idY);

    // Trigger direct download
    const safeFileName = name.replace(/[^a-zA-Z0-9]/g, '_');
    const link = document.createElement('a');
    link.download = `NIAT_AI_Workshop_Pass_${safeFileName}.png`;
    link.href = canvas.toDataURL('image/png');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  templateImg.onerror = () => {
    alert('Pass registered. Bring this pass ID to the venue: ' + passId);
  };
}

// 8. Google Calendar Template
function initCalendarGenerator() {
  const calBtns = document.querySelectorAll('.btn-add-calendar');

  calBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      
      const title = encodeURIComponent('NIAT Free Offline AI Workshop (Class 12)');
      const details = encodeURIComponent('Free Offline AI Workshop for Class 12 students. Learn practical AI for board exams, revision, NotebookLM, prompting, and build a hands-on project. Entry Pass ID: ' + registeredStudentState.passId);
      const location = encodeURIComponent('Kapil Kavuri Hub (KKH), Nanakramguda, Financial District, Hyderabad');
      
      const gCalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=20260830T043000Z/20260830T103000Z&details=${details}&location=${location}`;
      window.open(gCalUrl, '_blank');
    });
  });
}

// 9. WhatsApp Share
function initWhatsAppShare() {
  const shareBtns = document.querySelectorAll('.btn-share-whatsapp');

  shareBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const message = `Hey! I just registered for the free *NIAT Offline AI Workshop* for Class 12 students in Hyderabad (30 Aug 2026 at KKH Campus)! 🚀\n\nThey're teaching AI for board exams, revision, NotebookLM, and live project building. Register your free seat too: https://whatsapp.com/channel/0029VbBl4Yx8V0tfmX9Dhr38`;
      const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
      window.open(waUrl, '_blank');
    });
  });
}

// 10. Interactive Hero Prompt Simulation
function initInteractiveHeroDemo() {
  const promptTabs = document.querySelectorAll('.hero-prompt-tab');
  const promptDisplay = document.getElementById('hero-live-prompt');
  const responseDisplay = document.getElementById('hero-live-response');

  if (!promptTabs.length || !promptDisplay || !responseDisplay) return;

  const demoScenarios = {
    physics: {
      prompt: "Extract all key formulas & mental models for Electromagnetic Waves in 5 bullets",
      bullets: [
        "Speed of light: c = 1 / √(μ₀ε₀) = 3 × 10⁸ m/s",
        "E & B fields are in-phase and perpendicular to wave propagation",
        "Energy density: u_E = u_B = ½ ε₀E² = B²/(2μ₀)",
        "Poynting Vector: S = (1/μ₀)(E × B) represents energy flux",
        "Displacement Current concept & Maxwell's 4th equation"
      ]
    },
    revision: {
      prompt: "Create a 3-step active recall quiz for Organic Chemistry Named Reactions",
      bullets: [
        "Aldol Condensation: Reagent condition (dilute NaOH) + α-hydrogen check",
        "Cannizzaro Reaction: Non-enolizable aldehydes + conc. KOH",
        "Gabriel Phthalimide Synthesis: Prep of pure 1° aliphatic amines only"
      ]
    },
    project: {
      prompt: "Generate simple code structure for an AI Study Flashcard web app",
      bullets: [
        "HTML/CSS modern responsive layout with flip card animation",
        "State management for flashcard decks and spaced-repetition scores",
        "Perplexity & ChatGPT prompt bridge for auto-generating NCERT questions"
      ]
    }
  };

  promptTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      promptTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const type = tab.getAttribute('data-type') || 'physics';
      const data = demoScenarios[type];

      if (data) {
        promptDisplay.textContent = `"${data.prompt}"`;
        responseDisplay.innerHTML = data.bullets.map(b => `<li><span class="icon">⚡</span> <span>${b}</span></li>`).join('');
      }
    });
  });
}

// Confetti Effect
function triggerConfetti() {
  try {
    const count = 45;
    const colors = ['#7B1113', '#D4AF37', '#22C55E', '#FF5F56', '#9B1B26'];
    
    for (let i = 0; i < count; i++) {
      const el = document.createElement('div');
      el.style.position = 'fixed';
      el.style.zIndex = '99999';
      el.style.width = Math.random() * 8 + 6 + 'px';
      el.style.height = Math.random() * 8 + 6 + 'px';
      el.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
      el.style.top = '40%';
      el.style.left = '50%';
      el.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
      el.style.transform = 'translate(-50%, -50%)';
      el.style.pointerEvents = 'none';
      
      document.body.appendChild(el);
      
      const angle = Math.random() * Math.PI * 2;
      const velocity = Math.random() * 320 + 120;
      const x = Math.cos(angle) * velocity;
      const y = Math.sin(angle) * velocity - 120;
      
      el.animate([
        { transform: 'translate(-50%, -50%) scale(1)', opacity: 1 },
        { transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px)) rotate(${Math.random() * 720}deg) scale(0)`, opacity: 0 }
      ], {
        duration: Math.random() * 1000 + 1000,
        easing: 'cubic-bezier(0.25, 1, 0.5, 1)'
      }).onfinish = () => el.remove();
    }
  } catch (e) {
    console.error('Confetti animation error', e);
  }
}
